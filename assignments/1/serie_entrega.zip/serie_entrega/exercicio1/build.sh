#!/bin/sh

gcc int_to_string_test.c int_to_string.c -o int_to_string_test -g -Wall -pedantic
