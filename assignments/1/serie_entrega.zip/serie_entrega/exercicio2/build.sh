#!/bin/sh

gcc float_to_string_test.c float_to_string.c -o float_to_string_test -g -Wall -pedantic
