#!/bin/sh

gcc mini_snprintf.c mini_snprintf_test.c -o mini_snprintf_test -g -Wall -pedantic
