#!/bin/sh

gcc time_to_string.c time_to_string_test.c -o time_to_string_test -g -Wall -pedantic
