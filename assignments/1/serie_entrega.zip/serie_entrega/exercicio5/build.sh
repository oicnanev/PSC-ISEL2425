#!/bin/sh

gcc csv_show.c -o csv_show -g -Wall #-std=c2x
