/************************************************************
 * Module with all kind of symbols per section and more.
 */
int sym_data_public = 1;
static int sym_data_local = 2;
short sym_bss_public1;
long sym_bss_public2 = 0;
static int sym_bss_local;

extern int sym_undef_public1;
// The "extern" keyword may be omitted for functions. The result will be the same.
extern int sym_undef_public2();
int sym_undef_public3();
int sym_undef_public4();

static long sym_text_local() {
	static long sym_bss_local;
	static long sym_data_local = 3;
	int sym_stack = 4;
	
	sym_bss_local += 1;
	sym_data_local += 1;
	
	return sym_bss_public1 + sym_bss_local + sym_data_local + sym_stack;
}

long sym_text_public() {
	const char * s = "Read only section";
	return sym_text_local() + *s + sym_data_local + 
		   sym_bss_local + sym_undef_public1 + 
		   sym_undef_public2() + sym_undef_public3();
}
