short sym_common_public1 = 10;
int sym_undef_public1;
int sym_undef_public3() {
	return sym_common_public1;
}
int sym_undef_public2() {
    return sym_undef_public1;
}
