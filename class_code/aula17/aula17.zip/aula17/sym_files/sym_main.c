/**********************************************************************
 * Program with all kind of symbols per section and more.
 *
 */
#include <stdio.h>
extern long sym_text_public();

int main() {
    long r = sym_text_public();
    printf("sym_text_public() return %ld\n", r);
    return 0;
}