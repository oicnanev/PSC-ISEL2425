extern int f2();
extern int v2;
int f1() {
    return 5;
}
int v1 = 50;
int main() {
    return f1() + v1 + f2() + v2;
}