int v2 = 500;
int f2() {
    return 5000;
}