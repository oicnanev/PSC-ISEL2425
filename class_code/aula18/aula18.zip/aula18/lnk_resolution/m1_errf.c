#include <stdio.h>

int main() {
    int x = f();
    printf("x = 0x%x\n", x);
    return 0;
}