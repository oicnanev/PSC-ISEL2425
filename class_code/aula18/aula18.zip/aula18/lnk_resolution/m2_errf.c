float f() {
    return -1;
}