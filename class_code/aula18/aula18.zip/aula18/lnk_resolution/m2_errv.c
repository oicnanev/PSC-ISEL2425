double x;

void f() {
    x = -0.0;
}