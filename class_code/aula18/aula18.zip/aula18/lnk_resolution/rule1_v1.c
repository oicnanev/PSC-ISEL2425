int x = 15213;
long y = 123;

int main() {
    return 0;
}