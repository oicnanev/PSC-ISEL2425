int x = 15213;
int y;

void f() {
}