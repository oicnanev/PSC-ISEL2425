#include <stdio.h>
void f(void);

int x = 15213; // Strong symbol

int main() {
    f();
    printf("x = %d\n", x);
    return 0;
}