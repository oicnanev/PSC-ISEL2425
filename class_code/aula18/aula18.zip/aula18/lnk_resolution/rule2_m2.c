int x; // Weak symbol

void f() {
    x = 15212;
}