#include <stdio.h>
void f(void);

int x; // Weak symbol

int main() {
    x = 15213;
    f();
    printf("x = %d\n", x);
    return 0;
}