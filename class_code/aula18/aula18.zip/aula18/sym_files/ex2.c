int v1[] = {1, 2, 3, 4, 5};
long v2;
long v3 = 0;
short v4 = 12;
extern char v5;
static char * v6 = "xpto";
static int v7;
static long v8 = 1234;
extern int f3();

long f1() {
    return v5 + v7 + v8 + f3();
}

static char * f2() {
    return v6;
}

