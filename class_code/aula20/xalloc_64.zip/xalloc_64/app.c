#include <stdio.h>
#include <stdlib.h>
#include "dyn_alloc.h"
#include "dyn_dbg.h"

#define ALLOC_SIZE 100

void test1() {
	int i;
	printf("********************** Teste 1 begin **********************\n");
	init_heap();
	print_all();
	for (i = 0;;i++) {
		if (!xmalloc(ALLOC_SIZE))
			break;
		printf("Iteration = %d; Total size = %u Bytes\n", i, (i+1)*ALLOC_SIZE);
	}
	printf("Ok, no more memory.\n"
			 "Heap size +-= %u Bytes\n", i*ALLOC_SIZE);
	print_all();
	printf("*********************** Teste 1 end ***********************\n");
}


#define PRNT_CODE(c) printf(#c " = %p\n", c)
void test2() {
	char * p;
	char* a[10];
	printf("********************** Teste 2 begin **********************\n");
	init_heap();
	print_all();
	p = (char*)xmalloc(40*sizeof(char));
	print_all();
	xfree(p);
	print_all();
	PRNT_CODE(a[0] = (char*)xmalloc(32*sizeof(char)));
	print_all();
	PRNT_CODE(a[1] = (char*)xmalloc(2*sizeof(char)));
	print_all();
	PRNT_CODE(a[2] = (char*)xmalloc(33*sizeof(char)));
	print_all();
	PRNT_CODE(a[3] = (char*)xmalloc(50*sizeof(char)));
	print_all();
	PRNT_CODE(a[4] = (char*)xmalloc(100*sizeof(char)));
	print_all();
	xfree(a[0]);
	print_all();
	xfree(a[2]);
	print_all();
	xfree(a[1]);
	print_all();
	xfree(a[4]);
	print_all();
	
	PRNT_CODE(a[0] = (char*)xmalloc(45*sizeof(char)));
	print_all();
	
	xfree(a[3]);
	print_all();
	xfree(a[0]);
	print_all();
	printf("*********************** Teste 2 end ***********************\n");
}

int main() {
	test1();
	test2();
	
	return 0;
}
