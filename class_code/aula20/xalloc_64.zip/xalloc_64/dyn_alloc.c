#include <stdio.h>
#include "list.h"
#include "dyn_alloc.h"
#include "heap.h"

/***********************************************************************
 * Internal implementation
 **********************************************************************/
//#define HEAP_SIZE 8*1024*1024
#define HEAP_SIZE 1024
#define HEAP_ALLOC_FACTOR	1
// Size of block chunk to get from heap when there is no more blocks in free block list
//#define HEAP_ALLOC_SIZE	(HEAP_SIZE >> HEAP_ALLOC_FACTOR)
#define HEAP_ALLOC_SIZE	(500)
/* Block of memory for dynamic allocation */
/*static*/ uchar heap[HEAP_SIZE];
static uchar * waterline;
/* List of free blocks */
static DLink sentinel = {&sentinel, &sentinel};

/* Gets chunk of memory when there is no block large enough in the free blocks list.
 * It uses a predefined size to alloc memory or size parameter value if the last is greater.
 * The waterline is updated base on the memory allocated and the returned block is returned
 * as a free block.
 * @param request_size the minimum block size needed. It is normalized and it includes already space for header and footer.
 * @ret pointer to payload of block or NULL if there isn't enough memory to satisfy the request.
 */
static void * heap_alloc(uint request_size) {
	// The new size is normalized to DWSIZE
	uint normalized_size = NORMALIZE(HEAP_ALLOC_SIZE, DWSIZE);
	uint alloc_size = request_size > normalized_size ? request_size : normalized_size;
	// Return NULL if there is no block size to satisfy request
	if ((HEAP_SIZE - (waterline-heap)) < alloc_size)
		return NULL;	
	// Get pointer to payload data of block
	uchar * p = (uchar*)NORMALIZE((ulong)waterline + HDR_SIZE, DWSIZE); 
	waterline += alloc_size;
	// Initiate block as free block
	UPDATE(HDR(p), PACK(alloc_size, 0));
	UPDATE(FTR(p), PACK(alloc_size, 0));
	return p;
}

/* Returns chunk of memory to heap. heapFree does not validate blk_size so, if blk_size added to
 * waterline is greater than heap capacity, the beaviour is unpredictable. * 
 * @param size block to return.
 */
static void heap_free(uint blk_size) {
	waterline -= blk_size;
}

/* Fragment block if the remaining space (block_size - size) may support minimum dynamic allocation.
 * This function doensn't validate size normalization.
 */
static void place( void *p, uint size ) {
	int sz = GET_SIZE(HDR(p));
	int remain_sz = sz-size;
	if (remain_sz >= NORMALIZE(MIN_PAYLOAD_SIZE+HDR_SIZE+FTR_SIZE, DWSIZE)) {
		void * new_p;
		// Fragment 
		UPDATE(HDR(p), PACK(size, 1));
		UPDATE(FTR(p), PACK(size, 1));
		new_p = NEXT(p);
		UPDATE(HDR(new_p), PACK(remain_sz, 0));
		UPDATE(FTR(new_p), PACK(remain_sz, 0));
		list_add_front(&sentinel, new_p);		
	} else {
		UPDATE(HDR(p), PACK(sz, 1));
		UPDATE(FTR(p), PACK(sz, 1));
	}	
}

/* Free block and merge it with the neighbors that are also free. 
 */
static void free_block(void * p) {
	int is_alloc;
	void * first_block = get_first_block();
	if (p != first_block) {
		is_alloc = IS_ALLOC(HDR(p)-FTR_SIZE);
		// Merge with prev block if free 
		if ( ! is_alloc) {
			void * prev = PREV(p);
			int sz = GET_SIZE(HDR(p)) + GET_SIZE(HDR(prev));
			list_remove(prev);
			UPDATE(HDR(prev), PACK(sz, 0));
			UPDATE(FTR(prev), PACK(sz, 0));
			p = prev;
		}	
	}
	// Merge with next block if free 
	void *next = NEXT(p);
	if (next < (void*)waterline) {
		is_alloc = IS_ALLOC(HDR(next));
		if ( ! is_alloc) {
			int sz = GET_SIZE(HDR(p)) + GET_SIZE(HDR(next));
			list_remove(next);
			UPDATE(HDR(p), PACK(sz, 0));
			UPDATE(FTR(p), PACK(sz, 0));
			
		}
	}
	// Add free block to list of free blocks or return it to heap.
	if (NEXT(p) > waterline)
		heap_free(GET_SIZE(HDR(p)));
	else
		list_add_front(&sentinel, p);			
}

/***********************************************************************
	Algoritmos para pesquisa por um bloco livre:
	1. First fit: retorna logo que encontre o primeiro bloco com dimensão adequada.
	2. Best fit: numa estruturas de dados desordenada implica o percurso por todos os elementos; numa estrutura ordenada retorna o primeiro bloco com dimensão adequada. O peso computacional encontra-se na inserção ordenada.
	3. Next fit: estratégia parecida com o Best Fit com a diferença de iniciar a pesquisa por um bloco livre a partir do ponto onde encontrou o último bloco livre.
***********************************************************************/
/* Usado nas listas implícitas. Tem a vantagem de apresentar a tendência 
 * de manter os blocos maiores no fim da lista. 
 * A desvantagem é demorar cada vez mais tempo a encontrar um bloco livre 
 * se a dimensão solicitada tiver a tendência a aumentar. */
static void * first_fit(uint size) {
	DLink * it;
	for (it = sentinel.next; it != &sentinel; it = it->next) {
		int sz = GET_SIZE(HDR(it));
		if (sz >= size) {
			/* encontrou nó com dimensão adequada. Desliga-o da lista */
			list_remove(it);
			return it; /* retorna ponteiro para primeiro byte do Payload */
		}
	}
	return NULL;
}
/* First proposed by Donald Knuth para substituir a estratégia first_fit. 
 * O objectivo é reduzir o tempo de busca de um bloco livre. 
 * Apresenta a desvantagem de realizar uma pior utilização da memória */
static void * next_fit(size_t size) {
	return NULL;
}
/* Usado em listas explícitas que mantenham os blocos livre ordenados de acordo com as suas dimensões. 
 * Nas listas implícitas é pouco eficiente por exigir percorrer completamente 
 * a lista sempre que é solicitado um bloco livre. */
static void * best_fit(size_t size) {
	return NULL;
}

static void * find_fit(uint size) {
	return first_fit(size);
}

/***********************************************************************
	Public interface implementation of allocation service
***********************************************************************/
void * xmalloc(size_t size) {
	void * p;	
	
	if (size == 0) 
		return NULL;
		
	// Validate minimum size block (two pointers + hdr and footer size)
	size = (size < MIN_PAYLOAD_SIZE ? MIN_PAYLOAD_SIZE : size) + HDR_SIZE + FTR_SIZE;
	size = NORMALIZE(size, DWSIZE);
	
	// Search for a free block
	p = find_fit(size);
	if ( !p && !(p = heap_alloc(size)))
		return NULL; // No more free blocks
		
	// Fragment p block if greater than size
	place(p, size);
	
	return p;
}

void xfree(void *p) {
	int sz = GET_SIZE(HDR(p));
	
	// Mark block as free
	UPDATE(HDR(p), PACK(sz, 0));
	UPDATE(FTR(p), PACK(sz, 0));
	
	// Merge free block with neighbors and add it to list
	free_block(p);
}


void init_heap() {
	list_init(&sentinel);							// Initiate sentinel node
	waterline = (uchar*)NORMALIZE((ulong)heap + HDR_SIZE, DWSIZE) - HDR_SIZE;
}

/**************************************************************************************
	Public interface implementation of debug service
**************************************************************************************/
DLink * get_free_list(void) { return &sentinel; }
uchar * get_heap(void) { return heap; }
//uchar * get_first_block(void) { return (uchar*)NORMALIZE((long)heap + FTR_SIZE + HDR_SIZE, QWSIZE); }
uchar * get_first_block(void) { return (uchar*)NORMALIZE((long)heap + HDR_SIZE, DWSIZE); }
unsigned get_sizeof_heap(void) { return sizeof(heap); }
uchar * get_waterline(void) { return waterline; }
unsigned get_sizeof_heap_free(void) { return sizeof(heap) - (waterline - heap); }
