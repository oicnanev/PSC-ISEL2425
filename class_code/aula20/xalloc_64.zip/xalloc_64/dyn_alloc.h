#ifndef _DYN_ALLOC_H
#define _DYN_ALLOC_H

void init_heap();               // Inicia modelo de dados

void * xmalloc(size_t size);    // Aloca size bytes
void xfree(void * ptr);         // Liberta o espaço alocado

#endif/*_DYN_ALLOC_H*/
