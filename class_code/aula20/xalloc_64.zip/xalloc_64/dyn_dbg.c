/**************************************************************************************
	Algoritmos para apresentar o estado do heap:
	1. print_free_list: percorre a lista de blocos livres apresentando 
                        o estado de cada nó.
	2. print_implicit_list: percorre lista implícita com todos os blocos 
                            livres e ocupados.
	3. print_heap_state: apresenta o estado do heap.
**************************************************************************************/
#include <stdio.h>
#include "heap.h"
#include "list.h"

void print_free_list() {
	DLink *heap_free_p = get_free_list();
	DLink *p = heap_free_p->next;
	printf("------------------- Print explicit list -------------------\n");
	while (p != heap_free_p) {
		printf("p = %p;\tBlock size = %u;\tprev = %p;\tnext = %p\n", (void*)p, GET_SIZE(HDR(p)), (void*)p->prev, (void*)p->next);
		p = p->next;
	}
}
void print_heap_state() {
	uchar * heap = get_heap();
	uint sizeof_heap = get_sizeof_heap();
	printf("--------------------- Print heap state --------------------\n");
	printf("Heap begin addr = %p;\tHeap end addr  = %p;\twaterline = %p;\tHeap free size=%d;\n", 
		(void*)heap, (void*)(heap + sizeof_heap), (void*)get_waterline(), get_sizeof_heap_free());
}
void print_implicit_list() {
	uchar * p = get_first_block();
	uchar * wline = get_waterline();
	printf("------------------- Print implicit list -------------------\n");
	while (p < wline) {
		printf("p = %p;\tHdr size|alloc = %u|%s;\tFtr size|alloc = %u|%s;\n", 
		        p, GET_SIZE(HDR(p)), IS_ALLOC(HDR(p))?"true":"false", GET_SIZE(FTR(p)), IS_ALLOC(FTR(p))?"true":"false");
		p = NEXT(p);
	}
}

void print_all() {
	print_heap_state();
	print_implicit_list();
	print_free_list();
	putchar('\n');
}
