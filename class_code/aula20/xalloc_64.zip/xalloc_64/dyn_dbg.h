#ifndef _DYN_DBG_H
#define _DYN_DBG_H

/**************************************************************************************
	Algoritmos para apresentar o estado do heap:
	1. print_explicit_list: percorre a lista de blocos livres apresentando o estado de cada nó.
	2. print_implicit_list: percorre lista implícita com todos os blocos livres e ocupados.
	3. print_heap_state: apresenta o estado do heap.
**************************************************************************************/

void print_free_list(void);
void print_heap_state(void);
void print_implicit_list(void);
void print_all(void);

#endif/*_DYN_DBG_H*/
