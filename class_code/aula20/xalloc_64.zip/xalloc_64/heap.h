#ifndef _HEAP_H
#define _HEAP_H

#include "list.h"

typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned char uchar;

#define WSIZE					(sizeof(int))
#define DWSIZE					(sizeof(void*))
#define QWSIZE					(2 * DWSIZE)
#define HDR_SIZE				WSIZE
#define FTR_SIZE				WSIZE
#define NORMALIZE(size, mod) 	((mod) * (((size)+((mod)-1))/(mod)))
#define HDR(p) 					((uchar*)(p) - HDR_SIZE)
#define FTR(p) 					((uchar*)HDR(p)+GET_SIZE(HDR(p))-FTR_SIZE)
#define GET_SIZE(p) 			(*(uint*)(p) & ~1)
#define IS_ALLOC(p) 			(*(uint*)(p) & 1)
#define UPDATE(p, v) 			(*(uint*)(p) = v)
#define PACK(size, alloc) 		(((size)&~1) | (alloc&1))
#define NEXT(p) 				((uchar*)(p) + GET_SIZE(HDR(p)))
#define PREV(p) 				((uchar*)(p) - GET_SIZE(HDR(p)-FTR_SIZE))
#define MIN_PAYLOAD_SIZE		(2 * sizeof(void*))

/**************************************************************************************
	Interface pública para debug
**************************************************************************************/
DLink * get_free_list(void);
uchar * get_heap(void);
uchar * get_first_block(void);
unsigned get_sizeof_heap(void);
uchar * get_waterline(void);
unsigned get_sizeof_heap_free(void);

#endif/*_HEAP_H*/
