#include "list.h"

//static DLink sentinela = {&sentinela, &sentinela};

DLink * list_init(DLink *l) {
	l->next = l->prev = l;
	return l;
}
void list_add_front(DLink *l, DLink *v) {
	v->next = l->next;
	v->prev = l;
	l->next->prev = v;
	l->next = v;
}
void list_add_rear(DLink *l, DLink *v) {
	v->next = l;
	v->prev = l->prev;
	l->prev->next = v;
	l->prev = v;
}

DLink * list_remove(DLink *l) {
	l->next->prev = l->prev;
	l->prev->next = l->next;
	
	return l;
}
