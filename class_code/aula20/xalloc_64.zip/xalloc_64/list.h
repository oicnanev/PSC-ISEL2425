#ifndef _LIST_H
#define _LIST_H

typedef struct dlink {
	struct dlink *next, *prev;
} DLink;

DLink * list_init(DLink *l);
void list_add_front(DLink *l, DLink *v);
void list_add_rear(DLink *l, DLink *v);
DLink * list_remove(DLink *l);

#endif/*_LIST_H*/
