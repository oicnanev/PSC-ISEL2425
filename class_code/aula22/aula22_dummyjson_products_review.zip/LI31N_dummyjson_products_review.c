#include <stdio.h>
#include <stdlib.h>
#include <jansson.h>
#include "http_get_and_post_json.h"

#define MAX_URI							256
#define PRODUCT_URI 					"https://dummyjson.com/products"
#define PRODUCT_REVIEWS_KEY				"reviews"
#define PRODUCT_TITLE_KEY				"title"
#define REVIEW_RATING_KEY				"rating"
#define REVIEW_COMMENT_KEY				"comment"
#define REVIEW_DATE_KEY					"date"
#define REVIEW_REVIEWER_NAME_KEY		"reviewerName"
#define REVIEW_REVIEWER_MAIL_KEY		"reviewerEmail"

typedef struct {
	int rating;
	char *comment;
	char *date;
	char *reviewer_name;
	char *reviewer_mail;
} product_review_t;

product_review_t *product_review_get(json_t *reviews_array) {
	static json_t *st_reviews_array = NULL;
	static int idx = 0;
	if (reviews_array != NULL) {
		st_reviews_array = reviews_array;
		idx = 0;
	}
	
	json_t *review = json_array_get(st_reviews_array, idx);
	if (review == NULL) 
		return NULL;
		
	idx += 1;

	product_review_t *product_review = (product_review_t*)malloc(
		sizeof(product_review_t));
	int r = json_unpack(review, "{s:i, s:s, s:s, s:s, s:s}", 
		REVIEW_RATING_KEY, &product_review->rating,
		REVIEW_COMMENT_KEY, &product_review->comment,
		REVIEW_DATE_KEY, &product_review->date,
		REVIEW_REVIEWER_NAME_KEY, &product_review->reviewer_name,
		REVIEW_REVIEWER_MAIL_KEY, &product_review->reviewer_mail);
	if (r != 0)
		return NULL;
		
	product_review->rating = json_integer_value(
		json_object_get(review, REVIEW_RATING_KEY)
	);

	return product_review;
}

void product_review_print(int product_id) {
	char buffer[MAX_URI];
	snprintf(buffer, MAX_URI, "%s/%d?select=title,reviews", PRODUCT_URI, product_id);
	json_t *reviews_root = http_get_json(buffer);
	if (reviews_root == NULL)
		goto product_review_print_error;
		
	json_t *reviews_array;
	char *title;
	int r = json_unpack(reviews_root, "{s:s, s:o}", 
		PRODUCT_TITLE_KEY, &title,
		PRODUCT_REVIEWS_KEY, &reviews_array);
	//reviews_array = json_object_get(reviews_root, REVIEWS_KEY);
	if (r != 0)
		goto product_review_print_error;
	
	printf("Title: %s\n", title);	
	product_review_t *review = product_review_get(reviews_array);
	while (review != NULL) {
		printf("\tRating: %d\n", review->rating);
		printf("\tComment: %s\n", review->comment);
		printf("\tDate: %s\n", review->date);
		printf("\tReviewerName: %s\n", review->reviewer_name);
		printf("\tReviewerEmail: %s\n", review->reviewer_mail);
		free(review);
		review = product_review_get(NULL);
	}
product_review_print_error:
	json_decref(reviews_root);
}

int main(int argc, char *argv[]) {
	if (argc < 2) {
		fprintf(stderr, "Use %s <product_id>\n", argv[0]);
		return 1;
	}
	
	int product_id = atoi(argv[1]);
	product_review_print(product_id);
	
	return 0;
}
