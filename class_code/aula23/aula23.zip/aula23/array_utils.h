#ifndef _ARRAY_UTILS_H
#define _ARRAY_UTILS_H

void aprint(int a[], int size);
int asum(int a[], int size);

#endif/*_ARRAY_UTILS_H*/
