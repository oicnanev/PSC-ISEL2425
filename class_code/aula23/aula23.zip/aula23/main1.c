#include <stdio.h>
#include "../common.h"
#include "array_utils.h"

int v1[] = {1, 2, 3, 4};

int main(void) {
	PRINT_EXP(
		asum(v1, ARRAY_SIZE(v1))
	);
	aprint(v1, ARRAY_SIZE(v1));
	return 0;
}
