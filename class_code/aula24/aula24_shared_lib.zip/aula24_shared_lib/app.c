#include <stdio.h>
#include "m.h"

int main() {
    printf("f1() = %d\n", f1());
    return 0;
}