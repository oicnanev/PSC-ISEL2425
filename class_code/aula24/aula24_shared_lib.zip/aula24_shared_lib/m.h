#ifndef _M_H
#define _M_H

int f1(void);
int f2(void);
int f3(void);
extern int v1;

#endif/*_M_H*/