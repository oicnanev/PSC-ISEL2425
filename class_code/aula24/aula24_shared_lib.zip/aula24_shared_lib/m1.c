#include "m.h"

int f1(void) {
    return v1 + v1 + f2() + f2();
}