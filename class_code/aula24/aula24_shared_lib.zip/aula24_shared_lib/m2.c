int v1 = 10;

int f3(void) { return v1 * 10;   }
int f2(void) { return v1 + f3(); }