#include <stdio.h>
#include "m1.h"

#define PRINT_STEP(s)   \
    printf(s ". Press ENTER key to continue."); \
    getchar()

int main() {
    PRINT_STEP("1. Before libm2.so load");
    m1_init();
    PRINT_STEP("2. After libm2.so load");
    printf("f1() = %d\n", f1());
    m1_fini();
    PRINT_STEP("3. After libm2.so unload");
    return 0;
}