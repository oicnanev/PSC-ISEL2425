#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

#define EXIT_IF_NULL(h)                     \
    if ((h) == NULL) {                      \
        fprintf(stderr, "%s\n", dlerror()); \
        exit(1);                            \
    }
#define EXIT_IF_NZERO(h)                    \
    if ((h) != 0) {                         \
        fprintf(stderr, "%s\n", dlerror()); \
        exit(1);                            \
    }

void * hm2;

void m1_init() {
    EXIT_IF_NULL(hm2 = dlopen("./libm2.so", RTLD_NOW));
}
void m1_fini() {
    EXIT_IF_NZERO(dlclose(hm2));
}

int f1(void) {
    int * pv1;
    EXIT_IF_NULL(pv1 = (int*)dlsym(hm2, "v1"));
    int (*pf2)(void);
    EXIT_IF_NULL(*(void**)&pf2 = dlsym(hm2, "f2"));
    return *pv1 + *pv1 + pf2() + pf2();
}