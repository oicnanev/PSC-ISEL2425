#ifndef _M_H
#define _M_H

void m1_init();
void m1_fini();

int f1(void);

#endif/*_M_H*/